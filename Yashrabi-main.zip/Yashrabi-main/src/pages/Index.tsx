
import React from 'react';
import ChatUI from '@/components/chat/ChatUI';

const Index = () => {
  return (
    <div className="h-full">
      <ChatUI />
    </div>
  );
};

export default Index;
